# https://pypi.org/project/yfinance/
import yfinance as yf

# use pandas to create dataframes
import pandas as pd

# use matplotlib as aggr in background
import matplotlib
matplotlib.use('Agg')

def get_stock_info(ticker):
    try:
        stock = yf.Ticker(ticker)
        return stock.info
    except Exception as e: 
        print(e)
        return None

def get_stock_price(ticker, time):
    try:
        stock = yf.Ticker(ticker)
        return stock.history(period=time)
    except Exception as e: 
        print(e)
        return None

# test if function works
# print(get_stock_price('SIM.CO', '1mo'))