from datetime import date

def get_stock_analysis(data, ticker, time):
    data.columns.name='Date'
    data.index.name = None

    # using print statements to debug along the way
    # print(price.index)
    # print(price['Date'])
    # print(price)
    # print(price.keys())
    # print(price)
    
    # https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.to_html.html
    table = data.to_html(classes='table table-striped table-hover')
    
    data['Date'] = data.index

    # using print statements to debug along the way
    # print(price.keys())
    # print(price)
    # print(type(price))
    # print(table)
    # print(type(table))
    # graph_data = pd.DataFrame(price.to_dict())
    # print(graph_data)
    # x_data = graph_data.index
    # print(x_data)
    # print(type(x_data))

    date_today = str(date.today())

    ax = data.plot.bar(x='Date', y='High', rot=0)

    ax.set_xlabel('Date')
    ax.set_ylabel('Price')
    ax.set_title('Stock price for ' + ticker + ' (' + date_today + ')')

    if time == '1d':
        tick_indices = range(0, len(data['Date']), 1)
    elif time == '5d':
        tick_indices = range(0, len(data['Date']), 1)
    elif time == '1wk':
        tick_indices = range(0, len(data['Date']), 2)
    elif time == '1mo':
        tick_indices = range(0, len(data['Date']), 6)
    elif time == '3mo':
        tick_indices = range(0, len(data['Date']), 15)
    elif time == '1y':
        tick_indices = range(0, len(data['Date']), 60)

    data['Date'] = data['Date'].astype(str).str[:-15]
    tick_labels = [data['Date'][i] for i in tick_indices]
    # print(tick_labels)

    ax.set_xticks(tick_indices)
    ax.set_xticklabels(tick_labels)

    fig = ax.get_figure()
    
    path = date_today + '-' + ticker + '-' + time + '-stock.png'
    fig.savefig('static/' + path)

    # save data in a list and return it
    response = [table, path, date_today]
    return response

# test if function works
