import sqlite3

#Create table with stocks
create_stocks_table = """
CREATE TABLE IF NOT EXISTS stocks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ticker TEXT NOT NULL,
    share_price REAL,
    date TEXT
);
"""
# create table with transactions between selling and buying stocks
create_transaktion_table = """
CREATE TABLE IF NOT EXISTS transaktion (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    action TEXT NOT NULL,
    quantity INT,
    FOREIGN KEY (stocks_id) REFERENCES stocks(id),
    FOREIGN KEY (klient_id) REFERENCES klient(id)
);
"""
# create table with simcorp clients such as names and stock preferences
create_klient_table = """
CREATE TABLE IF NOT EXISTS klient (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL
);
"""
with sqlite3.connect('Database/simcorpdata.db') as conn:
    # cursor object
    c = conn.cursor()
    #create tables in database
    c.execute(create_stocks_table)
    c.execute(create_transaktion_table)
    c.execute(create_klient_table)
    #Insert values into stockstable in database
    c.execute("INSERT INTO stocks (ticker) VALUES ('AAPL')")
    c.execute("INSERT INTO stocks (ticker) VALUES ('TSLA')")
    c.execute("INSERT INTO stocks (ticker) VALUES ('SIM.CO')")
    #Insert value into transaktion table in database
    c.execute("INSERT INTO transaktion (action) VALUES ('buy')")
    c.execute("INSERT INTO transaktion (action) VALUES ('sell')")
    #Insert values into klient table in database
    c.execute("INSERT INTO klient (name) VALUES ('Payam')")

# Data Manipulation Language (DML) statements

read_stocks = """
    SELECT * FROM stocks;
"""

create_stocks = """
    INSERT INTO stocks (ticker, share_price, date)
    VALUES (?, ?, ?);
"""

read_transaktion = """
    SELECT * FROM transaktion;
"""

create_transaktion = """
    INSERT INTO transaktion (name, action, quantity)
    VALUES (?, ?, ?);
"""

read_klient = """
    SELECT * FROM klient;
"""

create_klient = """
    INSERT INTO klient (name)
    VALUES (?);
"""

