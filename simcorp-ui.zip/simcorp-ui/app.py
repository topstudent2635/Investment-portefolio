from flask import Flask, render_template, request, redirect, jsonify
import yfinance as yf
import os
import sqlite3
from api_request import *
from yfinance_analysis import *

app = Flask(__name__)
dir = os.path.dirname(__file__)
db = os.path.join(dir, 'Database/simcorpdata.db')

@app.route('/')
def index():
    stock_analysis = []
    return render_template('index.html', stock_analysis=stock_analysis)

@app.route('/', methods=['POST'])
def get_stock():
    # gets the values from the form in index.html
    ticker = request.form.get('ticker')
    time = request.form.get('time')

    # calls get_stock_price() from api_requests.py with two arguments
    price = get_stock_price(ticker, time)


    
    # calls get_stock_analysis() from analysis.py with three arguments
    stock_analysis = get_stock_analysis(price, ticker, time)
    
    
    
    # returns the index.html template with the variables passed in

    # DML
    '''
    # read all stocks from the database
    all_stocks = execute_read_query(connection, read_stocks)
    print(all_stocks)
    #print(stock_analysis)
    # check if the stock is already in the database
    
    #print(last_row[0])
    #print(stock_analysis[2])
    #print(time)
    #print(stock_analysis[1])
    
    execute_query_with_data(connection, create_stock, (ticker,))
    last_row = execute_query_lastrowid(connection)
    execute_query_with_data(connection, create_analysis, (last_row[0], stock_analysis[2], time, stock_analysis[1]))

    for stock in all_stocks:
        if ticker not in all_stocks:
            execute_query_with_data(connection, create_stock, (ticker,))
            last_row = execute_query_lastrowid(connection)
            execute_query_with_data(connection, create_analysis, (last_row[0], stock_analysis[2], time, stock_analysis[1]))
        if stock[1] == ticker:
            execute_query_with_data(connection, create_analysis, (stock[0], stock_analysis[2], time, stock_analysis[1]))


    ''''''
    for stock in all_stocks:
        if ticker not in all_stocks:
            execute_query_with_data(connection, create_stock, (ticker,))
            last_row = execute_query_lastrowid(connection)
            execute_query_with_data(connection, create_analysis, (last_row[0], stock_analysis[2], time, stock_analysis[1]))

        elif stock[1] == ticker:
            execute_query_with_data(connection, create_analysis, (last_row[0], stock_analysis[2], time, stock_analysis[1]))
        
        else:
            execute_query_with_data(connection, create_stock, (ticker,))
            last_row = execute_query_lastrowid(connection)
            execute_query_with_data(connection, create_analysis, (last_row[0], stock_analysis[2], time, stock_analysis[1]))
    '''
    return render_template('index.html', ticker=ticker, time=time, stock_analysis=stock_analysis)


@app.route('/aktie')
def aktie():
    with sqlite3.connect(db) as conn:
        c = conn.cursor()
        c.execute("SELECT * FROM stocks")
        stocks = c.fetchall()
        c.execute("SELECT * FROM transaktion")
        transaktion = c.fetchall()
        c.execute("SELECT * FROM klient")
        klient = c.fetchall()

    return render_template("aktie.html", stocks = stocks, transaktion = transaktion, klient = klient)

@app.route('/create', methods=['POST'])
def create():
    name = request.form.get('name')
    stocks = request.form.get('stocks')
    transaktion = request.form.get('transaktion')
    data = (name, stocks, transaktion)

    with sqlite3.connect(db) as conn:
        c = conn.cursor()
        c.execute("INSERT INTO transaktion (name, stocks_id, klient_id) VALUES (?, ?, ?)", data)

        return redirect ('/aktie')

@app.route('/update', methods=['POST'])
def update():
    selected_name = request.form.get('selected_name')
    stocks = request.form.get('stocks')
    transaktion = request.form.get('transaktion')
    data = (stocks, transaktion, selected_name)

    with sqlite3.connect(db) as conn:
        c = conn.cursor()
        c.execute("UPDATE transaktion SET stocks_id=?, klient_id=? WHERE id=?", data)

        return redirect ('/aktie')
    
@app.route('/delete', methods=['POST'])
def delete():
    selected_name = request.form.get('selected_name')
    data = (selected_name)

    with sqlite3.connect(db) as conn:
        c = conn.cursor()
        c.execute("DELETE FROM transaktion WHERE id=?", data)

        return redirect ('/aktie')


if __name__ == '__main__':
    app.run(debug=True)